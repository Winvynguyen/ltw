function initializeTabs(tabClass, contentClass) {
  const tabs = document.querySelectorAll(tabClass);
  const allContent = document.querySelectorAll(contentClass);

  tabs.forEach((tab, index) => {
      tab.addEventListener('click', () => {
          tabs.forEach(t => t.classList.remove('active'));
          tab.classList.add('active');

          allContent.forEach(content => content.classList.remove('active'));
          allContent[index].classList.add('active');
      });
  });
}

// Initialize tabs for each section
initializeTabs('#a', '#a1');
initializeTabs('#b', '#b1');
initializeTabs('#c', '#c1');
initializeTabs('#d', '#d1');
initializeTabs('#e', '#e1');
initializeTabs('#f', '#f1');

//Kiểm tra đăng ký
$(document).ready(function ()  {

function textSDT() {
  let SDT = $("#txtSDT").val();
  let regexSDT = /^0[1-9]{3}[0-9]{3}[0-9]{3}$/;
  if (SDT == "") {
      $("#erorrSDT").html("Vui lòng nhập số điện thoại")
      return false;
  }
  if (!regexSDT.test(SDT)) {
      $("#erorrSDT").html("Số điện thoại không hợp lệ")
      return false;
  } else {
      $("#erorrSDT").html("*")
      return true;
  }
}
$("#txtSDT").blur(textSDT);

function textEmail() {
  let Email = $("#txtEmail").val();
  let regexEmail = /^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$/;
  if (Email == "") {
      $("#erorrEmail").html("Vui lòng nhập email")
      return false;
  }
  if (!regexEmail.test(Email)) {
      $("#erorrEmail").html("Email không hợp lệ")
      return false;
  } else {
      $("#erorrEmail").html("*")
      return true;
  }
}
$("#txtEmail").blur(textEmail);

function textPassword() {
  let Password = $("#txtPassword").val();
  let regexPassword = /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[a-zA-Z]).{8,}$/;
  if (Password == "") {
      $("#erorrPassword").html("Vui lòng nhập Password")
      return false;
  }
  if (!regexPassword.test(Password)) {

      $("#erorrPassword").html("Dài >8,1 hoa,1 thường,1 số,1 đặc biệt")
      return false;
  } else {
      $("#erorrPassword").html("*")
      return true;
  }
}
$("#txtPassword").blur(textPassword);

function textRePass() {
  let RePass = $("#txtRePass").val();
  let regexRePass = $("#txtPassword").val();
  if (RePass == "") {
      $("#erorrRePass").html("Vui lòng nhập lại Password")
      return false;
  }
  if (regexRePass != RePass) {
      $("#erorrRePass").html("Nhập lại Password không đúng")
      return false;
  } else {
      $("#erorrRePass").html("*")
      return true;
  }
}
$("#txtRePass").blur(textRePass);


$("#registerForm").submit(function (event) {
    event.preventDefault(); // Ngăn chặn hành vi mặc định của biểu mẫu
    let isValidSDT = textSDT();
    let isValidEmail = textEmail();
    let isValidPassword = textPassword();
    let isValidRePass = textRePass();

});

$("#btnLuu").click(function () {
    var taiKhoan = $("#txtUsername").val();
    var email = $("#txtEmail").val();
    var soDT = $("#txtSDT").val();
    var mk = $("#txtPassword").val();
    var rePW = $("#txtRePass").val();

    // Lưu thông tin đăng ký
    localStorage.setItem('taiKhoan', taiKhoan);
    localStorage.setItem('email', email);
    localStorage.setItem('soDT', soDT);
    localStorage.setItem('mk', mk);
    localStorage.setItem('rePW', rePW);

    alert("Đăng ký thành công.");
    window.location.href = "index.html";
    return false;
});


});





// Đăng nhập
function login() {
var tk = localStorage.getItem('taiKhoan');
var mk = localStorage.getItem('mk');

var tkmd = document.getElementById('tk').value;
var mkmd = document.getElementById('mk').value;
if (tk && mk) {
    if (tk === tkmd && mk === mkmd) {
        alert("Đăng nhập thành công!");
        $('#myModal').modal('hide'); // Đóng modal
        // window.location.href = "home.html";

        // Thay thế nút Đăng nhập thành icon <i class="fa-solid fa-person"></i>
            document.getElementById('header').innerHTML = `
                <div class="logo">
                    <img class="logo-item" src="../assets/img/logo-white.png" alt="">
                </div>
                <div class="search">
                    <div class="search_bar">
                        <input type="search" placeholder="Tìm kiếm sản phẩm" class="search-input">
                    </div>
                    <button class="search-btn">
                        <i class="fa-solid fa-magnifying-glass"></i>
                    </button>
                </div>
                <div class="login_res">
                    <ul class="login_res-item">
                        <li class="cart">
                            <a href="../HTML/giohang.html">
                                <button class="login-cart">
                                    <i class="fa-solid fa-cart-shopping"></i>
                                </button>
                            </a>
                        </li>
                        <li class="login-boder"></li>
                        <li class="login">
                        <button class="login-btn"><a href="../HTML/infordangky.html" style="color: #333"><i class="fa-solid fa-person"></i></a></button>
                        </li>
                    </ul>
                </div>`;
    } else {
        alert("Tên người dùng hoặc mật khẩu không đúng.");
    }
} else {
    alert("Tài khoản không tồn tại.");
}
}


$("#txtModal").click(function() {
    $("#myModall").modal();
});



    var taiKhoan = localStorage.getItem('taiKhoan');
    var email = localStorage.getItem('email');
    var soDT = localStorage.getItem('soDT');
    var donhang = localStorage.getItem('donhang');

    let row = "<tr><td>" + taiKhoan + "</td><td>" + email + "</td><td>" + soDT + "</td><td>" + donhang + "</td></tr>";
    $("#tbody1 ").append(row);


// localStorage.clear();