$(document).ready(function(){
    var i = 1;

    function ktHoTen() {
        let hoTen = $("#txtHoTen").val().trim();
        let btcq = /^([A-Z][a-z]* )*([A-Z][a-z]*)$/;
        if(hoTen.length == 0) {
            $("#erorrHoTen").html("Họ tên không được để trống");
            $("#txtHoTen").focus();
            return false;
        } else if (btcq.test(hoTen)==false) {
            $("#erorrHoTen").html("Tên không hợp lệ");
            $("#txtHoTen").focus();
            return false;
        } else {
            $("#erorrHoTen").html("(*)");
            return true;
        } 
    }
    $("#txtHoTen").blur(function(){
        ktHoTen();
    });

    function ktSDT () {
        let SDT = $("#txtSDT").val();
        let regexSDT = /^0[1-9]{3}[0-9]{3}[0-9]{3}$/;
        if (SDT == "") {
            $("#erorrSDT").html("Vui lòng nhập số điện thoại")
            return false;
        }
        if (!regexSDT.test(SDT)) {
            $("#erorrSDT").html("Số điện thoại không hợp lệ")
            return false;
        } else {
            $("#erorrSDT").html("*")
            return true;
        }
    }
    $("#txtSDT").blur(function(e){
        ktSDT();
    });

    function ktDiaChi() {
        let diaChi = $("#txtDiaChi").val();
        if (diaChi == "") {
            $("#erorrDiaChi").html("Địa chỉ không được trống");
            return false;
        } else {
            $("#erorrDiaChi").html("(*)");
            return true;
        }
    }
    $("#txtDiaChi").blur(function(e){
        ktDiaChi();
    });

    $("#btnDatHang").click(function(e){
        if (ktHoTen() && ktSDT() && ktDiaChi()) {
            let hoTen = $("#txtHoTen").val();
            let sdt = $("#txtSDT").val();
            let diaChi = $("#txtDiaChi").val();
            localStorage.setItem('donhang',i)

            let tdNew = "<tr><td>" + (i++) + "</td><td>" + hoTen + "</td><td>" + sdt + "</td><td>" + diaChi + "</td><td>" + "24/11/2023" + "</td><td>" + "Đang chờ duyệt" + "</td></tr>";
            

            $("#tableDS").append(tdNew);
            $("#modalDH").modal("hide");
        
            alert("Đặt hàng thành công");
        } else {
            alert("Thông tin không hợp lệ");
        }
    })

})